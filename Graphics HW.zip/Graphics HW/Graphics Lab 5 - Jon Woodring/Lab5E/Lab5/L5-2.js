/*
 * L4D2.js
 * Demonstrate lighting.
 *
 * Adapted for WebGL by Alex Clarke, 2016.
 */


//----------------------------------------------------------------------------
// Variable Setup
//----------------------------------------------------------------------------

// This variable will store the WebGL rendering context
var gl;
var batman;

//Define points for
var cubeVerts = [
                 [ 0.5, 0.5, 0.5, 1], //0
                 [ 0.5, 0.5,-0.5, 1], //1
                 [ 0.5,-0.5, 0.5, 1], //2
                 [ 0.5,-0.5,-0.5, 1], //3
                 [-0.5, 0.5, 0.5, 1], //4
                 [-0.5, 0.5,-0.5, 1], //5
                 [-0.5,-0.5, 0.5, 1], //6
                 [-0.5,-0.5,-0.5, 1], //7
                 ];


var solidCubeStart = 0;
var solidCubeVertices = 36;

var wireCubeStart = 36;
var wireCubeVertices = 30;

//Look up patterns from cubeVerts for different primitive types
var cubeLookups = [
                   //Solid Cube - use TRIANGLES, starts at 0, 36 vertices
                   0,4,6, //front
                   0,6,2,
                   1,0,2, //right
                   1,2,3,
                   5,1,3, //back
                   5,3,7,
                   4,5,7, //left
                   4,7,6,
                   4,0,1, //top
                   4,1,5,
                   6,7,3, //bottom
                   6,3,2,
                   //Wire Cube - use LINE_STRIP, starts at 36, 30 vertices
                   0,4,6,2,0, //front
                   1,0,2,3,1, //right
                   5,1,3,7,5, //back
                   4,5,7,6,4, //left
                   4,0,1,5,4, //top
                   6,7,3,2,6, //bottom
                   ];

//load points into points array - runs once as page loads.
var points = [];
for (var i =0; i < cubeLookups.length; i++)
{
    points.push(cubeVerts[cubeLookups[i]]);
}

var left =  vec3(-1,0,0);
var right = vec3(1,0,0);
var down =  vec3(0,-1,0);
var up =    vec3(0,1,0);
var front = vec3(0,0,1);
var back =  vec3(0,0,-1);
var normals = [
               front, front, front, front, front, front,
               right, right, right, right, right, right,
               back, back, back, back, back, back,
               left, left, left, left, left, left,
               up, up, up, up, up, up,
               down, down, down, down, down, down
               ];
for (var i = 0; i < wireCubeVertices; i++)
{
    normals.push(up);
}

var red = 		 [1.0, 0.0, 0.0, 1.0];
var green = 	 [0.0, 1.0, 0.0, 1.0];
var blue = 		 [0.0, 0.0, 1.0, 1.0];
var lightred =   [1.0, 0.5, 0.5, 1.0];
var lightgreen = [0.5, 1.0, 0.5, 1.0];
var lightblue =  [0.5, 0.5, 1.0, 1.0];
var white = 	 [1.0, 1.0, 1.0, 1.0];
var black =      [0.0, 0.0, 0.0, 1.0];



//Variables for Transformation Matrices
var mv = new mat4();
var p  = new mat4();
var mvLoc, projLoc;

//Variables for Lighting
var light;
var material;
var lighting;
var uColor;

//You will need to rebind these buffers
//and point attributes at them after calling uofrGraphics draw functions
var vertexBuffer, normalBuffer;
var program;


function bindBuffersToShader()
{
	if(batman.loaded)
	{
    gl.bindBuffer(gl.ARRAY_BUFFER, batman.vertexObject);
    gl.vertexAttribPointer( program.vPosition, 3, gl.FLOAT, gl.FALSE, 0, 0 );
    gl.enableVertexAttribArray( program.vPosition );
    
    gl.bindBuffer(gl.ARRAY_BUFFER, batman.normalObject);
    gl.vertexAttribPointer( program.vNormal, 3, gl.FLOAT, gl.FALSE, 0, 0 );
    gl.enableVertexAttribArray( program.vNormal );
    
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, batman.indexObject);
      }
}

function setLightMode(event) 
{
    var type =(event.srcElement || event.target);
    if (type.value == "hemi")
		gl.uniform1i(light.hemisphere, 1);
	else
		gl.uniform1i(light.hemisphere, 0);
};


//----------------------------------------------------------------------------
// Initialization Event Function
//----------------------------------------------------------------------------

window.onload = function init()
{
    // Set up a WebGL Rendering Context in an HTML5 Canvas
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl)
    {
        alert("WebGL isn't available");
    }
    
    //  Configure WebGL
    //  eg. - set a clear color
    //      - turn on depth testing
    gl.clearColor(0.0,0.0,0.0,0);
    gl.enable(gl.BLEND);
    gl.enable(gl.DEPTH_TEST);
    
    //  Load shaders and initialize attribute buffers
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
    
    // Set up data to draw
    // Done globally in this program...
    
    // Load the data into GPU data buffers and
    // Associate shader attributes with corresponding data buffers
    //***Vertices***
    vertexBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vertexBuffer );
    gl.bufferData( gl.ARRAY_BUFFER,  flatten(points), gl.STATIC_DRAW );
    program.vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer( program.vPosition, 4, gl.FLOAT, gl.FALSE, 0, 0 );
    gl.enableVertexAttribArray( program.vPosition );
    
    
    //***Normals***
    normalBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, normalBuffer );
    gl.bufferData( gl.ARRAY_BUFFER,  flatten(normals), gl.STATIC_DRAW );
    program.vNormal = gl.getAttribLocation(program, "vNormal");
    gl.vertexAttribPointer( program.vNormal, 3, gl.FLOAT, gl.FALSE, 0, 0 );
    gl.enableVertexAttribArray( program.vNormal );
    
    //***Elements***
    indexBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData( gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(cubeLookups), gl.STATIC_DRAW);
        
    // Get addresses of transformation uniforms
    projLoc = gl.getUniformLocation(program, "p");
    mvLoc = gl.getUniformLocation(program, "mv");
    
    //Set up viewport
    gl.viewportWidth = canvas.width;
    gl.viewportHeight = canvas.height;
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    
    //Set up projection matrix
    p = perspective(45.0, gl.viewportWidth/gl.viewportHeight, 0.1, 100.0);
    gl.uniformMatrix4fv(projLoc, gl.FALSE, flatten(p));
    
    
    // Get and set light uniforms
	light = {};
    light.top = gl.getUniformLocation(program,"light.top");
    light.bottom = gl.getUniformLocation(program,"light.bottom");
    light.direction = gl.getUniformLocation(program,"light.direction");
    light.hemisphere = gl.getUniformLocation(program, "light.hemisphere");
    gl.uniform4fv(light.top, white);
    gl.uniform4fv(light.bottom, black);
    //light.direction is set by text boxes and placed in world with lookAt in render function
    light.dir = vec4(0,1,0,0);
    gl.uniform1i(light.hemisphere, 1);
    
    //match UI to default settings
  document.getElementById("topColor").jscolor.fromRGB(255, 255, 255);
  document.getElementById("bottomColor").jscolor.fromRGB(0, 0, 0);

  document.getElementById("dx").onchange = function(event) 
  {
    light.dir[0]=(event.srcElement || event.target).value;
    document.getElementById("directionval").innerHTML = light.dir[0];
  };
  document.getElementById("dy").onchange = function(event) 
  {
    light.dir[1]=(event.srcElement || event.target).value;
    document.getElementById("directionval").innerHTML = light.dir[1];
  };
  document.getElementById("dz").onchange = function(event) 
  {
    light.dir[2]=(event.srcElement || event.target).value;
    document.getElementById("directionval").innerHTML = light.dir[2];
  };
  document.getElementById("dx").value = light.dir[0];
  document.getElementById("dy").value = light.dir[1];
  document.getElementById("dz").value = light.dir[2];

  var toggleOptions = document.getElementsByName("toggle");
  
  for (var i = 0; i < toggleOptions.length; i++)
  {
  	toggleOptions[i].onchange = setLightMode;
  }  
    
    // Get and set material uniforms
    material = {};
    material.diffuse = gl.getUniformLocation(program, "material.diffuse");
    
    var diffuseColor = vec4(0.25, 0.3, 0.35, 1.0);
    gl.uniform4fv(material.diffuse, white);
    
    // Get and set other lighting state
    lighting = gl.getUniformLocation(program, "lighting");
    uColor = gl.getUniformLocation(program, "uColor");
    gl.uniform1i(lighting, 1);
    gl.uniform4fv(uColor, white);
    
    urgl = new uofrGraphics();
    urgl.connectShader(program, "vPosition", "vNormal", "stub");
    
    batman = loadObj(gl, "BatmanArmoured.obj");
    
    requestAnimFrame(render);
};

	function setTopColor(picker) {
		gl.uniform4f(light.top, picker.rgb[0]/255.0, picker.rgb[1]/255.0, picker.rgb[2]/255.0, 1);
	}
	function setBottomColor(picker) {
		gl.uniform4f(light.bottom, picker.rgb[0]/255.0, picker.rgb[1]/255.0, picker.rgb[2]/255.0, 1);
	}



//----------------------------------------------------------------------------
// Rendering Event Function
//----------------------------------------------------------------------------
var rx = 0, ry = 0;
function render()
{
    gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);
    
    
    //Set initial view
    var eye = vec3(0.0, 1.0, 6.0);
    var at =  vec3(0.0, 1.0, 0.0);
    var up =  vec3(0.0, 1.0, 0.0);
    
    mv = lookAt(eye,at,up);

	//Put light direction into world space
    gl.uniform4fv(light.direction, mult(transpose(mv), light.dir));

    //rebind local buffers to shader
    //necessary if uofrGraphics draw functions are used
    if (batman.loaded)
    {
		bindBuffersToShader();    
		//draw batman
		var cubeTF = mult(mv, mult(translate(0,-1,0),rotateY(ry)));
		gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(cubeTF));
		gl.drawElements(gl.TRIANGLES, batman.numIndices, gl.UNSIGNED_SHORT,0);	

    }

    var sphereTF = mult(mv, translate(-2,0,0));
    gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(sphereTF));
    urgl.drawSolidSphere(1,50,50);
    
    sphereTF = mult(mv, translate(2,0,0));
    gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(sphereTF));
    urgl.drawSolidSphere(1,50,50);
    
    ry += 0.5;

    requestAnimFrame(render);
}


