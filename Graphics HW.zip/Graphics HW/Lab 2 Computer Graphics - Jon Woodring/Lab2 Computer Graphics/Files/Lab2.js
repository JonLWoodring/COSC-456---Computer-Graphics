var gl; //Generic Var
var color; //Getting uniforms can be slow, so make this global
var sides = 5000;
var circleDrawn = false;
var pointSize;
var numPoints;
window.onload = function init()
{
    var canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) {
      alert("WebGL isn't available");
    }

    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    gl.clearColor(0.8, 0.8, 0.8, 1.0); //clear colour is black

    var points =
    [
      vec2( 0.99, 0.99),
      vec2(-0.99, 0.99),
      vec2(-0.99,-0.99),
      vec2( 0.99,-0.99),
      vec2( -0.5275, 0.555),
      vec2( -0.30, 0.255),
      vec2( -0.5275, 0.255),
      vec2( -0.30, 0.555),
      vec2( 0.5275, 0.555),
      vec2( 0.30, 0.255),
      vec2( 0.5275, 0.255),
      vec2( 0.30, 0.555),
      vec2( -0.50, -0.10),
      vec2( -0.74, -0.30),
      vec2( 0.50, -0.10),
      vec2( 0.74, -0.30),
      vec2( -0.62, -0.20),
      vec2( -0.42, -0.40),
      vec2( 0.62, -0.20),
      vec2( 0.42, -0.40),
      vec2( -0.42, -0.40),
      vec2(0.42, -0.40),
      vec2(-0.20, -0.20),
      vec2(0.0, 0.0), //23
      vec2(0.99, 0.0),
      vec2(0.80, 0.80)

    ];
    points = points.concat(circle(sides));
    pointSize = gl.getUniformLocation(program, "pointSize");
    var colors =
    [
       vec4(0.0, 0.0, 1.0, 1.0),
       vec4(0.0, 0.0, 1.0, 1.0),
       vec4(0.0, 0.0, 1.0, 1.0),
       vec4(0.0, 0.0, 1.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(0.0, 0.0, 0.0, 1.0),
       vec4(1.0, 0.6, 0.0, 1.0),  //22
       vec4(1.0, 0.6, 0.0, 1.0),  //23
       vec4(1.0, 0.6, 0.0, 1.0),
       vec4(0.8, 0.8, 0.8, 1.0),
       vec4(0.0, 0.0, 1.0, 1.0)

    ];

    colors = colors.concat(numColors(sides));

    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );


    //Create a buffer for vertex positions, make it active, and copy data to interval
    var positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW );

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.enableVertexAttribArray( vPosition );
    gl.vertexAttribPointer( vPosition, 2, gl.FLOAT, gl.FALSE, 0, 0 );

   //*** Colour buffer **********************
    // Create a buffer for colour positions, make it active, and copy data to it
    var colorBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, colorBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );

    //Enable the shader's vertex colour input and attach the active buffer
    var vColor = gl.getAttribLocation( program, "vColor");
    gl.enableVertexAttribArray( vColor );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, gl.FALSE, 0, 0 );


    render();
};
    function render()
    {
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);


        gl.drawArrays(gl.LINE_LOOP, 0, 4);
        gl.drawArrays(gl.LINES, 4, 22);
        gl.drawArrays(gl.TRIANGLES, 22, 26);
        gl.drawArrays(gl.POINTS, 26, 26);
        gl.drawArrays(gl.LINES, 26, sides);
     }

   function circle(sides)
   {
      var point1;
      var point2;
      var vertices = []; // create empty array
      if (sides < 3)
      {
          console.log("function circle: Not enough sides to make a polygon.");
      }
      else
      {
        if (sides > 10000)
        {
          sides = 10000;
          console.log("function circle: Sides limited to 10,000.");
        }
        for (var i = sides; i >= 0; i--)
        {
          point1 = Math.cos(i/sides*2*Math.PI);
          point2 = Math.sin(i/sides*2*Math.PI);
          if(point1 > 0)
          {
            point1 -= 0.03;
          }
          else
          {
            point1 += 0.03;
          }
          if(point2 > 0)
          {
            point2 -= 0.03;
          }
          else
          {
            point2 += 0.03;
          }
           vertices.push(vec2(point1, point2));
        }
      }
        return vertices;
     }
    function numColors(sides)
    {
      var numColors = [];
      for(var t = 0; t <= sides; t++)
      {
        numColors.push(vec4(0, 0, 0, 1));
      }
        return numColors;
    }
