/*
 * L4D1.js
 * Demonstrate Color Swizzeling
 *
 * Adapted for WebGL by Alex Clarke, 2016.
 */


//----------------------------------------------------------------------------
// Variable Setup
//----------------------------------------------------------------------------

// This variable will store the WebGL rendering context
var gl;



var points = [
  	 -1, 0, 0,
	    1, 0, 0,
      0, 1, 0
];

var colors = [
	 vec4(1, 0, 0, 1),
	 vec4(0, 1, 0, 1),
	 vec4(0, 0, 1, 1)
];

var program;

//----------------------------------------------------------------------------
// Initialization Event Function
//----------------------------------------------------------------------------

window.onload = function init()
{
    // Set up a WebGL Rendering Context in an HTML5 Canvas
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl)
    {
        alert("WebGL isn't available");
    }

    //  Configure WebGL
    //  eg. - set a clear color
    //      - turn on depth testing
    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    //  Load shaders and initialize attribute buffers
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // Set up data to draw
    // Done globally in this program...

 // Load the data into GPU data buffers
  // The vertex array is copied into one buffer
  var vertex_buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer);
  gl.bufferData(gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW);

  // The colour array is copied into another
  var color_buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, color_buffer);
  gl.bufferData(gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW);


  // Associate shader attributes with corresponding data buffers
  var vPosition = gl.getAttribLocation(program, "vPosition");
  gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer);
  gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(vPosition);

  var vColor = gl.getAttribLocation(program, "vColor");
  gl.bindBuffer(gl.ARRAY_BUFFER, color_buffer);
  gl.vertexAttribPointer(vColor, 3, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(vColor);

    //Draw the scene
    requestAnimFrame(render);
};




//----------------------------------------------------------------------------
// Rendering Event Function
//----------------------------------------------------------------------------
function render()
{
    gl.clear(gl.DEPTH_BUFFER_BIT);

    //draw triangle
    gl.drawArrays(gl.TRIANGLES, 0, 3);


    requestAnimFrame(render);
}
